﻿using UnityEngine;
using System.Collections;

/// <summary>
/// Clase que permite destruir un objeto pasado un tiempo.
/// </summary>
public class Destroy_By_Time : MonoBehaviour {

    [SerializeField]
    float lifeTime = 1;   
	
	void Start () {     
        
        Destroy(gameObject, lifeTime);
	}   

    


}
