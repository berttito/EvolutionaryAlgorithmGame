﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// Clase encargada de la rotacion de la flecha, tiene un punto que toma 
/// como referencia para rotar y una limitación para que no sea 360º
/// </summary>
public class AssetsMovement : MonoBehaviour {

    /// <summary>
    /// Punto de referencia para la rotacion
    /// </summary>
    Transform rotatePoint;

    /// <summary>
    /// Velocidad de rotación
    /// </summary>
    [SerializeField]
    float speed;

    /// <summary>
    /// Eje sobre el que va a rotar
    /// </summary>
    Vector3 axis;


    /// <summary>
    /// Vector utilizado para la rotacion
    /// </summary>
    Vector3 myRotation;

    /// <summary>
    /// Limitacion de la rotacion en funcion del eje x
    /// </summary>
    [SerializeField]
    float limitRotationPos, limitRotationNeg;

    private void Start()
    {
        rotatePoint = GameObject.Find("Bullet").GetComponent<Transform>();
        axis = Vector3.up;
        myRotation = transform.rotation.eulerAngles;
    }

    void Update()
    {
        //Rotacion
        transform.RotateAround(rotatePoint.position, axis, speed * Time.deltaTime);
        myRotation.z = Mathf.Clamp(myRotation.z, -45f, 45f);

        //Limitacion de la rotacion
        if (transform.position.x >= limitRotationPos || transform.position.x <= limitRotationNeg)
            axis *= -1;
    }

 
    
}
