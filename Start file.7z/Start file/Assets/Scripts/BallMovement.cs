﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// Clase encargada del movimiento de la bola, tiene un rebote 
/// cuando choca con las paredes y se reposiciona cuando llega al final del campo de juego
/// </summary>
public class BallMovement : MonoBehaviour {

    /// <summary>
    /// Booleano para saber cuando mover la bola
    /// </summary>
    bool move;   

    /// <summary>
    /// Velocidad de movimiento de la bola
    /// </summary>
    [SerializeField]
    float speed;

    /// <summary>
    /// Transform de la flecha de direccion
    /// </summary>
    [SerializeField]
    Transform arrowTr;

    /// <summary>
    /// Vector donde se guarda la posicion inicial de la bola
    /// </summary>
    [SerializeField]
    Vector3 startPos;

    /// <summary>
    /// Vector donde se guarda la direccion que va a tener la bola
    /// </summary>
    Vector3 dir;
   
    /// <summary>
    /// Rigidbody de la bola
    /// </summary>
    Rigidbody rb;

    /// <summary>
    /// Transform de la posicion donde va a spawnear la bola
    /// </summary>
    [SerializeField]
    Transform lastPosition;

    /// <summary>
    /// Gameobject de la flecha
    /// </summary>
    [SerializeField]
    GameObject arrow;

    // Use this for initialization
    void Start ()
    {
        move = false;        
        startPos = transform.position;
        
        rb = GetComponent<Rigidbody>();
	}
	
	// Update is called once per frame
	void Update () {

        //Cuando pulsamos el raton se dispara la bola
        if (Input.GetMouseButtonDown(0) && !move)
        {
            Shoot();
            dir = (arrowTr.position - lastPosition.position).normalized;
            dir = new Vector3(dir.x, 0, dir.z);
        }

        //Se activa el movimiento de la bola
        if (move)
        {
            rb.velocity = dir * speed;
        }        
    }

    /// <summary>
    /// Funcion para el disparo de la bola que activa el movimiento y hace desaparecer la flecha
    /// </summary>
    void Shoot()
    {
        arrow.SetActive(false);
        move = true;
    }

    /// <summary>
    /// Funcion de reposicionamiento de la bola cuando sale del campo
    /// Devuelve la bola a la posicion inicial y vuelve a activar la flecha
    /// </summary>
    void Repositionate()
    {
        rb.velocity = Vector3.zero;
        arrow.SetActive(true);
        transform.position = startPos;      
        move = false;        
    }   

    /// <summary>
    /// Cuando la bola colisiona con las paredes se invierte la direccion en el eje z
    /// Si sale del campo se reposiciona
    /// </summary>
    /// <param name="collision"></param>
    private void OnTriggerEnter(Collider collision)
    {        
        if (collision.tag == "BgDestroy")
        {
            Repositionate();
            CameraShaker.instance.shouldShake = true;
        }            

        if (collision.tag == "Wall")
        {
            dir = new Vector3(dir.x, 0, -dir.z);
        }
    }
}
