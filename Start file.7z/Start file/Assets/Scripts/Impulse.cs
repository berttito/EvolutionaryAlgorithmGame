﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// Script que controla el impulso que realizan los enemigos cada cierto tiempo
/// </summary>
public class Impulse : MonoBehaviour {

    /// <summary>
    /// Rigidbody del enemigo que causa el impulso
    /// </summary>
    Rigidbody rb;

    /// <summary>
    /// Cantidad del impulso que se realiza
    /// </summary>
    public float impulse { get; set; }

    /// <summary>
    /// Lista de objetos que se encuentran dentro del radio de impulso
    /// </summary>
    [SerializeField]
    List<GameObject> objectsInSphere = new List<GameObject>();

    /// <summary>
    /// Frecuencia de tiempo para realizar el impulso
    /// </summary>
    public float impulseFrequence { get; set; }

    /// <summary>
    /// Particulas que se instancian cuando se hace un impulso
    /// </summary>
    [SerializeField]
    GameObject dust;

	// Use this for initialization
	void Start ()
    {
        rb = GetComponent<Rigidbody>();
        InvokeRepeating("ImpulseEnemies", impulseFrequence, impulseFrequence);
    }
	
	// Update is called once per frame
	void Update () {
        
        transform.localPosition = Vector3.zero;
    }

    /// <summary>
    /// Metodo para realizar el impulso sobre los enemigos que se encuentran dentro del radio de impulso
    /// </summary>
    public void ImpulseEnemies()
    {
        GameObject gb = Instantiate(dust, new Vector3(transform.parent.position.x, dust.transform.position.y, transform.parent.position.z), dust.transform.rotation);
        gb.transform.SetParent(transform.parent);
        gb.transform.localScale = new Vector3(1,1,1);

        for (int i = 0; i < objectsInSphere.Count; i++)
        {
            if(objectsInSphere[i] != null)
            {
                Rigidbody rigidBody = objectsInSphere[i].GetComponent<Rigidbody>();

                rigidBody.AddExplosionForce(impulse, transform.position, 5);
            }
        }
    }

    /// <summary>
    /// Metodos para introducir y sacar de la lista los enemigos que se van encontrando en el radio de impulso
    /// </summary>
    /// <param name="other"></param>
    private void OnTriggerEnter(Collider other)
    {
        if(other.tag == "Enemy")
            objectsInSphere.Add(other.gameObject);
    }

    private void OnTriggerExit(Collider other)
    {
        if (other.tag == "Enemy")
            objectsInSphere.Remove(other.gameObject);
    }
}
