﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
/// <summary>
/// Este script permite hacer un camera shake cuando la bola sale del campo
/// </summary>
public class CameraShaker : MonoBehaviour {
    
    /// <summary>
    ///Fuerza con la que se ejecuta el shake
    /// </summary>
    public float power = 0.7f;
  
    /// <summary>
    ///Duracion del shake
    /// </summary>
    public float duration = 1.0f;

    /// <summary>
    ///Transform de la camara
    /// </summary>
    public Transform camara;
        
    /// <summary>
    ///Cantidad por la que vamos restando la duracion
    /// </summary>
    public float slowDownAmount = 1.0f;
       
    /// <summary>
    ///Booleano que controla cuando debe ejecutarse el shake
    /// </summary>
    public bool shouldShake = false;
        
    /// <summary>
    ///Posicion inicial
    /// </summary>
    Vector3 startPosition;
        
    /// <summary>
    ///Duracion inicial 
    /// </summary>
    float initialDuration;

    public static CameraShaker instance;

    private void Awake()
    {
        instance = this;
    }


    // Use this for initialization
    void Start () {
        camara = Camera.main.transform;
        startPosition = camara.localPosition;
        initialDuration = duration;
	}
	
	// Update is called once per frame
	void Update () {

        //Si puede ejecutar el shake compruebo la duracion 
        if (shouldShake)
        {
            //Hacemos el shake hasta que la duracion llegue a 0
            if(duration > 0)
            {
                camara.localPosition = startPosition + Random.insideUnitSphere * power;
                duration -= Time.deltaTime * slowDownAmount;
            }

            //Restablecemos los parametros iniciales para que pueda volver a ejecutarse
            else
            {
                shouldShake = false;
                duration = initialDuration;
                camara.localPosition = startPosition;
            }
        }
	}
}
